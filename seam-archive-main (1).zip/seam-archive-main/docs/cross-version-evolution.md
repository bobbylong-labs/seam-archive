# Cross-Version Evolution

This document tracks how seam behavior and transcript structure evolve across:
- GPT-4
- GPT-5
- GPT-5.1
