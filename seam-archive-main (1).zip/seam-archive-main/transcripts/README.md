# Transcripts

This directory contains transcripts organized by model version:

- `gpt-4/`
- `gpt-5/`
- `gpt-5.1/`
