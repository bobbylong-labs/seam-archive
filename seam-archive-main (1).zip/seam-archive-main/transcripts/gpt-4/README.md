# GPT-4 Transcripts

Canonical transcripts generated with GPT-4.

- Stable, finalized conversations only.
- Use consistent naming: `YYYY-MM-DD-topic-or-session-id.md`.
