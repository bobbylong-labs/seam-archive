# GPT-5 Transcripts

Canonical transcripts generated with GPT-5.

Same naming rules as other versions:
- `YYYY-MM-DD-topic-or-session-id.md`
